# termux-filemanager

A real, working file manager for Termux, served over the web. List, open,
edit, upload, download, rename, move, copy, and delete files and folders —
every action runs an actual filesystem command on the device. No more
fighting Termux's storage sandbox through a clunky Android file picker.

## Setup (in Termux)

```bash
cd termux-filemanager
pkg install python
pip install -r requirements.txt --break-system-packages
```

If you want to browse your phone's shared storage (Downloads, DCIM,
WhatsApp media, etc.) instead of just Termux's private home folder, run
this once first:

```bash
termux-setup-storage
```

That creates `~/storage/shared`, which you can point the file manager at
(see Configuration below).

## Run

```bash
bash start.sh
```

It'll print something like:

```
Local    : http://localhost:8080/?token=AbCd1234...
Network  : http://<your-LAN-IP>:8080/?token=AbCd1234...
```

- Open the **Local** URL in the browser on the same device.
- To use it from your laptop or another phone on the same Wi-Fi, find this
  device's LAN IP (`ifconfig` or `ip addr`, usually something like
  `192.168.x.x`) and use the **Network** URL pattern with that IP instead
  of `localhost`.

The token in the URL is required — it's regenerated every time you start
the server, so bookmark the URL fresh each session, or pin it with
`FM_TOKEN` (below).

## Configuration

All configuration is environment variables, set before `bash start.sh`:

| Variable       | Default            | What it does                                   |
|----------------|--------------------|-------------------------------------------------|
| `FM_BASE_DIR`  | `~` (home)         | The root folder you're allowed to browse/edit.  |
| `FM_PORT`      | `8080`             | Port the server listens on.                     |
| `FM_TOKEN`     | random each run    | Fixed access token instead of a random one.     |

Example — browse shared phone storage on a fixed port and token:

```bash
export FM_BASE_DIR=~/storage/shared
export FM_PORT=9090
export FM_TOKEN=mysecret
bash start.sh
```

## What it can do

- **Browse** — folder listing with a `d`/`-` prefix (directory vs file),
  size, and breadcrumb navigation.
- **Edit** — tap any text file to open it in a full-screen editor and save
  changes directly to disk. Binary files and anything over 2MB offer a
  download instead.
- **Upload** — the upload button, or drag-and-drop files onto the page
  (handy from a desktop browser).
- **Download** — pulls the real file off the device.
- **New file / new folder / rename / move / copy / delete** — all via the
  `⋯` menu on each row, backed by real `os`/`shutil` calls.

## Security

This is built for your own private network, not the open internet:

- Every `/api/*` request requires the token (as `?token=` or an
  `X-Auth-Token` header). Without it, the server just says no.
- Every path is resolved against `FM_BASE_DIR` and rejected if it would
  escape it (via `../`, an absolute path, or a symlink) — so even with the
  token, you can't wander outside the folder you've configured.
- There's no login system beyond the token, and traffic isn't encrypted
  (plain HTTP). Don't port-forward this to the public internet as-is.

## Files

```
termux-filemanager/
├── backend.py       Flask server: all filesystem operations + API
├── static/
│   └── index.html   The file manager UI (single page, no build step)
├── start.sh          Launches the backend, waits for it to come up, prints the URL
├── requirements.txt  Python deps (just flask)
└── README.md          This file
```
