"""
Termux File Manager — backend.py

A self-contained, web-based file manager for Termux (or any Linux box).
Every action you take in the browser — list, open, edit, upload, download,
rename, move, copy, delete — runs a real filesystem operation on this
device. It's meant to replace Termux's built-in file handling with
something you can actually use from a normal browser, wirelessly, from
your phone or any device on the same Wi-Fi.

SECURITY NOTE: whoever has the URL + token gets full read/write access to
everything under BASE_DIR. This is built for your own private network, not
the open internet. A random token is generated each run (or set FM_TOKEN
yourself) and is required on every API request. Don't port-forward this to
the public internet without adding real auth.

Install (in Termux):
    pkg install python
    pip install flask --break-system-packages

Run:
    python3 backend.py       (or: bash start.sh)

Then open the URL printed on startup (it includes the token).
"""

import os
import shutil
import secrets
import logging
from datetime import datetime

from flask import Flask, request, jsonify, send_file, send_from_directory

# ---- CONFIGURE THIS ----
# Defaults to your home directory. On Termux that's the app's private
# sandbox (~/), which is exactly where your projects live. To browse
# shared phone storage (Downloads, DCIM, etc.) instead, run
# `termux-setup-storage` once, then point this at ~/storage/shared.
BASE_DIR = os.environ.get("FM_BASE_DIR", os.path.expanduser("~"))
PORT = int(os.environ.get("FM_PORT", "8080"))
TOKEN = os.environ.get("FM_TOKEN") or secrets.token_urlsafe(16)
MAX_TEXT_EDIT_BYTES = 2 * 1024 * 1024  # files bigger than this open as download-only
# -------------------------

BASE_DIR = os.path.realpath(BASE_DIR)
APP_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(APP_DIR, "static")
LOG_DIR = os.path.join(APP_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(LOG_DIR, "server.log")),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("filemanager")

app = Flask(__name__, static_folder=None)


# ---------------- path safety ----------------
# Every operation below takes a path *relative to BASE_DIR* from the client
# and resolves it with safe_path(), which refuses anything that would land
# outside BASE_DIR (via "../", an absolute path, or a symlink). This is the
# one function standing between "file manager" and "anyone on my Wi-Fi can
# read /etc/passwd" — every route must go through it.

class UnsafePath(Exception):
    pass


def safe_path(rel_path):
    rel_path = (rel_path or "").lstrip("/")
    candidate = os.path.realpath(os.path.join(BASE_DIR, rel_path))
    if candidate != BASE_DIR and not candidate.startswith(BASE_DIR + os.sep):
        raise UnsafePath(rel_path)
    return candidate


def rel(path):
    """Inverse of safe_path — an absolute path back to one relative to BASE_DIR."""
    r = os.path.relpath(path, BASE_DIR).replace(os.sep, "/")
    return "" if r == "." else r


@app.errorhandler(UnsafePath)
def handle_unsafe(e):
    log.warning("Blocked path traversal attempt: %r", str(e))
    return jsonify({"error": "path escapes the base directory"}), 400


# ---------------- auth ----------------

@app.before_request
def check_token():
    if request.path.startswith("/api/"):
        supplied = request.headers.get("X-Auth-Token") or request.args.get("token")
        if supplied != TOKEN:
            return jsonify({"error": "bad or missing token"}), 401


# ---------------- frontend ----------------

@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


@app.route("/config")
def config():
    # Public (no token needed) so the page can bootstrap itself. The token
    # is still required for every /api/ call — this just avoids the
    # awkwardness of hardcoding it into index.html.
    return jsonify({"token": TOKEN, "base_dir": BASE_DIR})


# ---------------- listing ----------------

def entry_info(full_path):
    st = os.stat(full_path, follow_symlinks=False)
    is_dir = os.path.isdir(full_path)
    return {
        "name": os.path.basename(full_path),
        "path": rel(full_path),
        "is_dir": is_dir,
        "is_symlink": os.path.islink(full_path),
        "size": None if is_dir else st.st_size,
        "mtime": datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
    }


@app.route("/api/list")
def api_list():
    target = safe_path(request.args.get("path", ""))
    if not os.path.isdir(target):
        return jsonify({"error": "not a directory"}), 400
    try:
        names = os.listdir(target)
    except PermissionError:
        return jsonify({"error": "permission denied"}), 403

    def sort_key(n):
        return (not os.path.isdir(os.path.join(target, n)), n.lower())

    entries = []
    for name in sorted(names, key=sort_key):
        try:
            entries.append(entry_info(os.path.join(target, name)))
        except OSError:
            continue  # skip broken symlinks / races
    return jsonify({"path": rel(target), "entries": entries})


# ---------------- read / write (text editor) ----------------

@app.route("/api/read")
def api_read():
    target = safe_path(request.args.get("path", ""))
    if not os.path.isfile(target):
        return jsonify({"error": "not a file"}), 400
    size = os.path.getsize(target)
    if size > MAX_TEXT_EDIT_BYTES:
        return jsonify({"error": f"file too large to edit here ({size} bytes) — download it instead"}), 413
    try:
        with open(target, "r", encoding="utf-8") as f:
            content = f.read()
    except UnicodeDecodeError:
        return jsonify({"error": "binary file — use download instead"}), 415
    return jsonify({"path": rel(target), "content": content})


@app.route("/api/write", methods=["POST"])
def api_write():
    data = request.get_json(force=True)
    target = safe_path(data.get("path", ""))
    content = data.get("content", "")
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "w", encoding="utf-8") as f:
        f.write(content)
    log.info("WRITE %s (%d bytes)", rel(target), len(content))
    return jsonify({"ok": True, "path": rel(target)})


# ---------------- mkdir / new file ----------------

@app.route("/api/mkdir", methods=["POST"])
def api_mkdir():
    data = request.get_json(force=True)
    target = safe_path(data.get("path", ""))
    if os.path.exists(target):
        return jsonify({"error": "already exists"}), 409
    os.makedirs(target)
    log.info("MKDIR %s", rel(target))
    return jsonify({"ok": True, "path": rel(target)})


@app.route("/api/create", methods=["POST"])
def api_create():
    data = request.get_json(force=True)
    target = safe_path(data.get("path", ""))
    if os.path.exists(target):
        return jsonify({"error": "already exists"}), 409
    os.makedirs(os.path.dirname(target), exist_ok=True)
    open(target, "a").close()
    log.info("CREATE %s", rel(target))
    return jsonify({"ok": True, "path": rel(target)})


# ---------------- delete / move / copy ----------------

@app.route("/api/delete", methods=["POST"])
def api_delete():
    data = request.get_json(force=True)
    target = safe_path(data.get("path", ""))
    if target == BASE_DIR:
        return jsonify({"error": "refusing to delete the base directory itself"}), 400
    if not os.path.exists(target):
        return jsonify({"error": "not found"}), 404
    if os.path.isdir(target) and not os.path.islink(target):
        shutil.rmtree(target)
    else:
        os.remove(target)
    log.info("DELETE %s", rel(target))
    return jsonify({"ok": True})


@app.route("/api/move", methods=["POST"])
def api_move():
    data = request.get_json(force=True)
    src = safe_path(data.get("src", ""))
    dst = safe_path(data.get("dst", ""))
    if not os.path.exists(src):
        return jsonify({"error": "source not found"}), 404
    if os.path.exists(dst):
        return jsonify({"error": "destination already exists"}), 409
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.move(src, dst)
    log.info("MOVE %s -> %s", rel(src), rel(dst))
    return jsonify({"ok": True, "path": rel(dst)})


@app.route("/api/copy", methods=["POST"])
def api_copy():
    data = request.get_json(force=True)
    src = safe_path(data.get("src", ""))
    dst = safe_path(data.get("dst", ""))
    if not os.path.exists(src):
        return jsonify({"error": "source not found"}), 404
    if os.path.exists(dst):
        return jsonify({"error": "destination already exists"}), 409
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isdir(src):
        shutil.copytree(src, dst)
    else:
        shutil.copy2(src, dst)
    log.info("COPY %s -> %s", rel(src), rel(dst))
    return jsonify({"ok": True, "path": rel(dst)})


# ---------------- upload / download ----------------

@app.route("/api/upload", methods=["POST"])
def api_upload():
    target_dir = safe_path(request.form.get("path", ""))
    if not os.path.isdir(target_dir):
        return jsonify({"error": "target is not a directory"}), 400
    saved, skipped = [], []
    for f in request.files.getlist("files"):
        if not f.filename:
            continue
        name = os.path.basename(f.filename)
        dest = safe_path(os.path.join(rel(target_dir), name))
        if os.path.exists(dest):
            skipped.append(name)
            continue
        f.save(dest)
        saved.append(rel(dest))
        log.info("UPLOAD %s", rel(dest))
    return jsonify({"ok": True, "saved": saved, "skipped": skipped})


@app.route("/api/download")
def api_download():
    target = safe_path(request.args.get("path", ""))
    if not os.path.isfile(target):
        return jsonify({"error": "not a file"}), 400
    return send_file(target, as_attachment=True, download_name=os.path.basename(target))


if __name__ == "__main__":
    lan_hint = "http://<your-phone-or-pc-LAN-IP>:%d/?token=%s" % (PORT, TOKEN)
    print("=" * 64)
    print(" Termux File Manager")
    print(" Base dir : %s" % BASE_DIR)
    print(" Local    : http://localhost:%d/?token=%s" % (PORT, TOKEN))
    print(" Network  : %s" % lan_hint)
    print("            (find your LAN IP with: ifconfig  or  ip addr)")
    print("=" * 64)
    log.info("Starting file manager on port %d, base_dir=%s", PORT, BASE_DIR)
    app.run(host="0.0.0.0", port=PORT)
