#!/usr/bin/env bash
# Starts the file manager backend and prints the URL to open (with token).
# All output is captured to logs/ so nothing gets lost if the terminal closes.

set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

mkdir -p logs
STAMP=$(date +"%Y%m%d_%H%M%S")
RUN_LOG="logs/start_${STAMP}.log"

echo "[$(date)] Launching file manager..." | tee -a "$RUN_LOG"
python3 backend.py >> "$RUN_LOG" 2>&1 &
BACKEND_PID=$!
echo "[$(date)] Backend PID: $BACKEND_PID" | tee -a "$RUN_LOG"

trap 'echo "[$(date)] Stopping backend (PID $BACKEND_PID)..." | tee -a "$RUN_LOG"; kill "$BACKEND_PID" 2>/dev/null' EXIT

PORT="${FM_PORT:-8080}"
echo "[$(date)] Waiting for backend to respond..." | tee -a "$RUN_LOG"
for i in $(seq 1 20); do
  if curl -s -o /dev/null --max-time 1 "http://localhost:${PORT}/config"; then
    echo "[$(date)] Backend is up." | tee -a "$RUN_LOG"
    break
  fi
  sleep 0.5
done

echo ""
echo "Open the URL printed above (it includes your access token)."
echo "To reach it from another device on the same Wi-Fi, swap localhost"
echo "for this device's LAN IP (find it with: ifconfig  or  ip addr)."
echo ""
echo "Run log: $RUN_LOG"
echo "Server log: logs/server.log"
echo ""
echo "Press Ctrl+C to stop the server."

wait "$BACKEND_PID"
